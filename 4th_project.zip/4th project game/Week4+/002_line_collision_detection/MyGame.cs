using System;
using GXPEngine;
using System.Drawing;
using System.Collections.Generic;
//using GXPEngine.Sound;




public class MyGame : Game
{
  

    static void Main() {
		new MyGame().Start();
	}

	EasyDraw _text;

  
	List<Sprite> panels;
	public List<Sprite> rocks;
    public List<Sprite> wing;
    public List<Sprite> rocket;
    Sprite menuBackground;
	Sprite[] levelBackgrounds = new Sprite[4];
	Sprite[] levelSelection = new Sprite[10];
	Sprite satellite;
	public Sprite mediumAsteroid;

	AnimationSprite explosion;
	public bool toExplode = false;

	public List<LineSegment> pannels;
	public List<LaserPath> laserPaths;

    private SoundChannel musicChannel;
    private Sound clickSound;
    private Sound asteroidDestroy;


    int currentScene = 0;
    int lastScene;

	public String textToShow = "no text";

	Vec2 start;

	bool isDragging;
	public int whichPanel;

	public MyGame () : base(1000, 750, false,false)
	{
        Sound music = new Sound("../../../assets/bgMusic.mp3");
        musicChannel = music.Play();

        Sound clickSound = new Sound("../../../assets/playButton.wav");
        Sound asteroidDestroy = new Sound("../../../assets/asteroidExploding.wav");

        menuBackground = new Sprite("../../../assets/menuBackground.png");

		levelBackgrounds[0] = new Sprite("../../../assets/bg-level1.png");
		levelBackgrounds[1] = new Sprite("../../../assets/bg-level2.png");
		levelBackgrounds[2] = new Sprite("../../../assets/bg-level3.png");
		levelBackgrounds[3] = new Sprite("../../../assets/bg-level4.png");

		levelSelection[0] = new Sprite("../../../assets/3_locked_1st_selected.png");
		levelSelection[1] = new Sprite("../../../assets/2_locked_1st_selected.png");
		levelSelection[2] = new Sprite("../../../assets/2_locked_2nd_selected.png");
		levelSelection[3] = new Sprite("../../../assets/1_locked_1st_selected.png");
		levelSelection[4] = new Sprite("../../../assets/1_locked_2nd_selected.png");
		levelSelection[5] = new Sprite("../../../assets/1_locked_3rd_selected.png");
		levelSelection[6] = new Sprite("../../../assets/0_locked_1st_selected.png");
		levelSelection[7] = new Sprite("../../../assets/0_locked_2nd_selected.png");
		levelSelection[8] = new Sprite("../../../assets/0_locked_3rd_selected.png");
		levelSelection[9] = new Sprite("../../../assets/0_locked_4th_selected.png");

		satellite = new Sprite("../../../assets/satellite.png");
        satellite.SetOrigin(0, satellite.height / 2);
        satellite.SetScaleXY(0.5f, 0.5f);

        mediumAsteroid = new Sprite("../../../assets/medium_asteroid.png");

        



        rocks = new List<Sprite>();
        wing = new List<Sprite>();
        rocket = new List<Sprite>();
        panels = new List<Sprite>();
		pannels = new List<LineSegment>();
        

        LoadScene(0, -1);

		//start = new Vec2(game.width / 2, game.height - 20);
		//start = new Vec2(0, 0);

		//aim = new LineSegment(start, end, 0xff00ff00, 2);
		//AddChild(aim);

		laserPaths = new List<LaserPath>();

		//_text = new EasyDraw(250, 250);
  //      _text.TextAlign(CenterMode.Min, CenterMode.Min);
  //      AddChild(_text);

    
    }


	public void AddLaserPath(Vec2 pStart, Vec2 pDirection)
	{
		LaserPath laser = new LaserPath(pStart, pStart + pDirection, pDirection);
		AddChild(laser);
		laserPaths.Add(laser);
	}

	void LoadScene(int sceneNumber,  int lastScene)
	{
      


        switch (sceneNumber)
		{
			//menu
			case 0:

				menuBackground.SetXY(0, 0);
				AddChild(menuBackground);

				currentScene = 0;

			break;

			//level selection
			case 1:

				if (lastScene == 0)
				{
					AddChild(levelBackgrounds[0]);

					levelSelection[6].SetXY(115, 200);
					AddChild(levelSelection[6]);
					menuBackground.Remove();
				}

				if (lastScene == 2)
				{

					foreach (Sprite sprite in rocks)
					{
						sprite.Destroy();
					}
					rocks.Clear();

                    foreach (Sprite sprite in wing)
                    {
                        sprite.Destroy();
                    }
                    wing.Clear();

                    foreach (Sprite sprite in rocket)
                    {   
                        sprite.Destroy();
                    }
                    rocket.Clear();

                    foreach (Sprite sprite1 in panels)
					{
						sprite1.Destroy();
					}
					panels.Clear();

					foreach (LineSegment lineSegment in pannels)
					{
						lineSegment.Remove();
					}
					pannels.Clear();

					satellite.Remove();
					explosion.Destroy();

					toExplode = false;

					AddChild(levelBackgrounds[0]);

					levelSelection[7].SetXY(115, 200);
					AddChild(levelSelection[7]);
					menuBackground.Remove();
				}


                if (lastScene == 3)
                {

                    foreach (Sprite sprite in rocks)
                    {
                        sprite.Destroy();
                    }
                    rocks.Clear();

                    foreach (Sprite sprite in wing)
                    {
                        sprite.Destroy();
                    }
                    wing.Clear();

                    foreach (Sprite sprite in rocket)
                    {
                        sprite.Destroy();
                    }
                    rocket.Clear();

                    foreach (Sprite sprite1 in panels)
                    {
                        sprite1.Destroy();
                    }
                    panels.Clear();

                    foreach (LineSegment lineSegment in pannels)
                    {
                        lineSegment.Remove();
                    }
                    pannels.Clear();

                    satellite.Remove();
                    explosion.Destroy();

                    toExplode = false;

                    AddChild(levelBackgrounds[0]);

                    levelSelection[5].SetXY(115, 200);
                    AddChild(levelSelection[5]);
                    menuBackground.Remove();
                }

                if (lastScene == 4)
                {
                    AddChild(levelBackgrounds[0]);

                    levelSelection[9].SetXY(115, 200);
                    AddChild(levelSelection[9]);
                    menuBackground.Remove();
                }



                else
				{

				}

                

                currentScene = 1;

				break;

			//1st level
			case 2:
                ClearLevel();
                
                // Sprite[] sprites = FindObjectsOfType<Sprite>();
                // for (int i = 0; i < sprites.Length; i++)
                //  {
                //     sprites[i].Remove();
                // }

                AddChild(levelBackgrounds[0]);

                for (int i = 0; i < 4; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rocket.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocket.Add(sprite);
                }

                for (int i = 0; i < 7; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/wing.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    wing.Add(sprite);
                }

                for (int i = 0; i < 8; i++) {
					Sprite sprite = new Sprite("../../../assets/rock.png");
					sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
					sprite.SetScaleXY(0.8f, 0.8f);
					AddChild(sprite);
					rocks.Add(sprite);
				}
				rocks[0].SetXY(600, 70);
				rocks[1].SetXY(500, 128);
				rocks[2].SetXY(219, 213);
				rocks[3].SetXY(409, 277);
				rocks[4].SetXY(690, 300);
				rocks[5].SetXY(840, 392);
				rocks[6].SetXY(271, 436);
				rocks[7].SetXY(476, 494);

				for (int i = 0; i < 2; i++) {

					LineSegment lineSegment = new LineSegment(new Vec2(0, 0), new Vec2(0, 0), 0xffffffff);
					AddChild(lineSegment);
					pannels.Add(lineSegment);

					Sprite sprite = new Sprite("../../../assets/panel.png");
					sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
					sprite.SetScaleXY(0.5f, 0.5f);
					AddChild(sprite);
					panels.Add(sprite);
				}
				panels[0].SetXY(100, 700);
				panels[1].SetXY(800, 700);

				satellite.SetXY(game.width / 2, game.height - 20);
				AddChild(satellite);

				mediumAsteroid.SetScaleXY(0.8f, 0.8f);
                mediumAsteroid.SetOrigin(mediumAsteroid.width / 2, mediumAsteroid.height / 2);
                mediumAsteroid.SetXY(780, 30);
				AddChild(mediumAsteroid);

				explosion = new AnimationSprite("../../../assets/Explosion.png", 6, 1);
				explosion.SetOrigin(explosion.width / 2, explosion.height / 2);
				explosion.SetScaleXY(0.8f, 0.8f);
				explosion.SetXY(780, 30);
				AddChild(explosion);
				

				currentScene = 2;
                

				break;

            // Level 2
            case 3:
                
                ClearLevel();

                
                    AddChild(levelBackgrounds[1]);


                for (int i = 0; i < 4; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rocket.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocket.Add(sprite);
                }


                for (int i = 0; i < 9; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rock.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocks.Add(sprite);
                }
                rocks[0].SetXY(100, 100);
                rocks[1].SetXY(300, 560);
                rocks[2].SetXY(430, 350);
                rocks[3].SetXY(717, 100);
                rocks[4].SetXY(100, 250);
                rocks[5].SetXY(305, 257);
                rocks[6].SetXY(560, 532);
                rocks[7].SetXY(700, 250);
                rocks[8].SetXY(710, 550);


                for (int i = 0; i < 7; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/wing.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    wing.Add(sprite);
                }

                wing[0].SetXY(120, 400);
                wing[1].SetXY(500, 400);
                wing[2].SetXY(500, 60);
                wing[3].SetXY(721, 413);
                wing[4].SetXY(106, 550);
                wing[5].SetXY(378, 552);
                wing[6].SetXY(560, 250);
                


                for (int i = 0; i < 2; i++)
                {

                    LineSegment lineSegment = new LineSegment(new Vec2(0, 0), new Vec2(0, 0), 0xffffffff);
                    AddChild(lineSegment);
                    pannels.Add(lineSegment);

                    Sprite sprite = new Sprite("../../../assets/panel.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.5f, 0.5f);
                    AddChild(sprite);
                    panels.Add(sprite);
                }
                panels[0].SetXY(100, 700);
                panels[1].SetXY(800, 700);

                
                //satellite.SetOrigin(0, satellite.height / 2);
                satellite.SetXY(game.width / 2, game.height - 20);
                //satellite.SetScaleXY(0.5f, 0.5f);
                AddChild(satellite);




                mediumAsteroid.SetScaleXY(0.8f, 0.8f);
                mediumAsteroid.SetOrigin(mediumAsteroid.width / 2, mediumAsteroid.height / 2);
                mediumAsteroid.SetXY(330, 100);
                AddChild(mediumAsteroid);

               
                explosion = new AnimationSprite("../../../assets/Explosion.png", 6, 1);
                explosion.SetOrigin(explosion.width / 2, explosion.height / 2);
                explosion.SetScaleXY(0.8f, 0.8f);
                explosion.SetXY(330, 100);
                AddChild(explosion);

                currentScene = 3;
                

                break;

            // Level 3
            case 4:
                
                ClearLevel();

                
                AddChild(levelBackgrounds[2]);


                for (int i = 0; i < 4; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rocket.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocket.Add(sprite);
                }
                rocket[0].SetXY(500, 350);
                rocket[1].SetXY(375, 293);
                rocket[2].SetXY(641, 623);
                rocket[3].SetXY(889, 659);


                for (int i = 0; i < 9; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rock.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocks.Add(sprite);
                }
                rocks[0].SetXY(143, 89);
                rocks[1].SetXY(259, 221);
                rocks[2].SetXY(513, 67);
                rocks[3].SetXY(671, 301);
                rocks[4].SetXY(95, 389);
                rocks[5].SetXY(329, 513);
                rocks[6].SetXY(543, 453);
                rocks[7].SetXY(771, 589);
                rocks[8].SetXY(137, 641);


                for (int i = 0; i < 7; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/wing.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    wing.Add(sprite);
                }

                wing[0].SetXY(407, 173);
                wing[1].SetXY(300, 425);
                wing[2].SetXY(731, 137);
                wing[3].SetXY(59, 511);
                wing[4].SetXY(281, 665);
                wing[5].SetXY(533, 587);
                wing[6].SetXY(683, 409);

                for (int i = 0; i < 2; i++)
                {

                    LineSegment lineSegment = new LineSegment(new Vec2(0, 0), new Vec2(0, 0), 0xffffffff);
                    AddChild(lineSegment);
                    pannels.Add(lineSegment);

                    Sprite sprite = new Sprite("../../../assets/panel.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.5f, 0.5f);
                    AddChild(sprite);
                    panels.Add(sprite);
                }
                panels[0].SetXY(100, 700);
                panels[1].SetXY(800, 700);


               // satellite.SetOrigin(0, satellite.height / 2);
                satellite.SetXY(game.width / 2, game.height - 20);
               // satellite.SetScaleXY(0.5f, 0.5f);
                AddChild(satellite);


                mediumAsteroid.SetScaleXY(0.8f, 0.8f);
                mediumAsteroid.SetOrigin(mediumAsteroid.width / 2, mediumAsteroid.height / 2);
                mediumAsteroid.SetXY(280, 70);
                AddChild(mediumAsteroid);

                explosion = new AnimationSprite("../../../assets/Explosion.png", 6, 1);
                explosion.SetOrigin(explosion.width / 2, explosion.height / 2);
                explosion.SetScaleXY(0.8f, 0.8f);
                explosion.SetXY(280, 70);
                AddChild(explosion);

                currentScene = 4;
                
                break;


            // Level 4
            case 5:
                
                ClearLevel();

                
                AddChild(levelBackgrounds[3]);

                for (int i = 0; i < 4; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rocket.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocket.Add(sprite);
                }
                rocket[0].SetXY(103, 719);
                rocket[1].SetXY(375, 293);
                rocket[2].SetXY(641, 623);
                rocket[3].SetXY(500, 359);


                for (int i = 0; i < 9; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/rock.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    rocks.Add(sprite);
                }
                rocks[0].SetXY(143, 89);
                rocks[1].SetXY(259, 221);
                rocks[2].SetXY(513, 67);
                rocks[3].SetXY(671, 301);
                rocks[4].SetXY(95, 389);
                rocks[5].SetXY(329, 513);
                rocks[6].SetXY(543, 453);
                rocks[7].SetXY(771, 589);
                rocks[8].SetXY(137, 641);


                for (int i = 0; i < 7; i++)
                {
                    Sprite sprite = new Sprite("../../../assets/wing.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.8f, 0.8f);
                    AddChild(sprite);
                    wing.Add(sprite);
                }

                wing[0].SetXY(407, 173);
                wing[1].SetXY(300, 425);
                wing[2].SetXY(731, 137);
                wing[3].SetXY(59, 511);
                wing[4].SetXY(281, 665);
                wing[5].SetXY(533, 587);
                wing[6].SetXY(683, 409);

                for (int i = 0; i < 2; i++)
                {

                    LineSegment lineSegment = new LineSegment(new Vec2(0, 0), new Vec2(0, 0), 0xffffffff);
                    AddChild(lineSegment);
                    pannels.Add(lineSegment);

                    Sprite sprite = new Sprite("../../../assets/panel.png");
                    sprite.SetOrigin(sprite.width / 2, sprite.height / 2);
                    sprite.SetScaleXY(0.5f, 0.5f);
                    AddChild(sprite);
                    panels.Add(sprite);
                }
                panels[0].SetXY(100, 700);
                panels[1].SetXY(800, 700);


                //satellite.SetOrigin(0, satellite.height / 2);
                satellite.SetXY(game.width / 2, game.height - 20);
                //satellite.SetScaleXY(0.5f, 0.5f);
                AddChild(satellite);


                mediumAsteroid.SetScaleXY(0.8f, 0.8f);
                mediumAsteroid.SetOrigin(mediumAsteroid.width / 2, mediumAsteroid.height / 2);
                mediumAsteroid.SetXY(280, 70);
                AddChild(mediumAsteroid);

                explosion = new AnimationSprite("../../../assets/Explosion.png", 6, 1);
                explosion.SetOrigin(explosion.width / 2, explosion.height / 2);
                explosion.SetScaleXY(0.8f, 0.8f);
                explosion.SetXY(280, 70);
                AddChild(explosion);

                currentScene = 5;
                break;

 
        }


	}



	void Update()
	{
		Vec2 aimDirection = new Vec2(Mathf.Cos(satellite.rotation * (Mathf.PI / 180)), Mathf.Sin(satellite.rotation * (Mathf.PI / 180)));
		start = new Vec2(game.width / 2, game.height - 20) + aimDirection * 100;

        if (isDragging && laserPaths.Count == 0)
        {
            panels[whichPanel].SetXY(Input.mouseX, Input.mouseY);

            if (Input.GetKey(Key.A))
            {
                panels[whichPanel].rotation = panels[whichPanel].rotation - 2;

            }
            if (Input.GetKey(Key.D))
            {
                panels[whichPanel].rotation = panels[whichPanel].rotation + 2;
            }

            if (panels[whichPanel].rotation > 360) { panels[whichPanel].rotation = 0; }
            if (panels[whichPanel].rotation < 0) { panels[whichPanel].rotation = 360; }

            Vec2 center = new Vec2(panels[whichPanel].x, panels[whichPanel].y);
            Vec2 direction = new Vec2(Mathf.Cos(panels[whichPanel].rotation * (Mathf.PI / 180)), Mathf.Sin(panels[whichPanel].rotation * (Mathf.PI / 180)));
            pannels[whichPanel].start = center + direction * 50;
            pannels[whichPanel].end = center + direction * -50;

        }

        if (currentScene == 0)
        {
            if (Input.GetMouseButtonDown(0) && new Vec2(Input.mouseX - 312, Input.mouseY - 526).Length() <= 60)
            {
                
                LoadScene(1, currentScene);
            }
        }



        if (currentScene == 1)
        {
            
            if (Input.GetMouseButtonDown(0) && new Vec2(Input.mouseX - 189, Input.mouseY - 275).Length() <= 63)
            {
                LoadScene(2, currentScene);
            }

            if (Input.GetMouseButtonDown(0) && new Vec2(Input.mouseX - 405, Input.mouseY - 275).Length() <= 63)
            {
                LoadScene(3, currentScene);
            }

            if (Input.GetMouseButtonDown(0) && new Vec2(Input.mouseX - 615, Input.mouseY - 275).Length() <= 63)
            {
                LoadScene(4, currentScene);
            }

            if (Input.GetMouseButtonDown(0) && new Vec2(Input.mouseX - 825, Input.mouseY - 275).Length() <= 63)
            {
                LoadScene(5, currentScene);
            }

        }





        if (currentScene == 2) {

			if (toExplode)
			{

                explosion.SetCycle(0, 5);
				explosion.Animate(0.1f);

                if (explosion.currentFrame == 4)
                {
                    mediumAsteroid.Remove();
					LoadScene (1,2);
                }
            }
			else {
				explosion.SetFrame(5);
			}

            


            if (satellite != null && laserPaths.Count == 0) {
				satellite.rotation = Mathf.Atan2(Input.mouseY - satellite.y, Input.mouseX - satellite.x) * (180 / Mathf.PI);
			}

			if (Input.GetMouseButtonDown(0))
			{
				for (int i = 0; i < 2; i++) {

					if (Input.mouseX >= panels[i].x - panels[i].width / 2 && Input.mouseX <= panels[i].x + panels[i].width / 2 && Input.mouseY >= panels[i].y - panels[i].height / 2 && Input.mouseY <= panels[i].y + panels[i].height / 2) {
						isDragging = true;
						whichPanel = i;
					}
				}
			}

			


			if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;

				for (int i = 0; i < rocks.Count; i++) {

					if (new Vec2(Input.mouseX - rocks[i].x, Input.mouseY - rocks[i].y).Length() <= 35) {

						pannels[whichPanel].start = new Vec2(0, 0);
						pannels[whichPanel].end = new Vec2(0, 0);

						if (whichPanel == 0) {
							panels[whichPanel].SetXY(100, 700);
						}
						if (whichPanel == 1)
						{
							panels[whichPanel].SetXY(800, 700);
						}
					}
				}

			}




        }

		

        if (currentScene == 3)
        {

            if (toExplode)
            {
                explosion.SetCycle(0, 5);
                explosion.Animate(0.1f);

                if (explosion.currentFrame == 4)
                {
                    mediumAsteroid.Remove();
                    LoadScene(1, 3);
                }
            }
            else
            {
                explosion.SetFrame(5);
            }




            if (satellite != null && laserPaths.Count == 0)
            {
                satellite.rotation = Mathf.Atan2(Input.mouseY - satellite.y, Input.mouseX - satellite.x) * (180 / Mathf.PI);
            }

            if (Input.GetMouseButtonDown(0))
            {
                for (int i = 0; i < 2; i++)
                {

                    if (Input.mouseX >= panels[i].x - panels[i].width / 2 && Input.mouseX <= panels[i].x + panels[i].width / 2 && Input.mouseY >= panels[i].y - panels[i].height / 2 && Input.mouseY <= panels[i].y + panels[i].height / 2)
                    {
                        isDragging = true;
                        whichPanel = i;
                    }
                }
            }




            if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;

                for (int i = 0; i < rocks.Count; i++)
                {

                    if (new Vec2(Input.mouseX - rocks[i].x, Input.mouseY - rocks[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

                for (int i = 0; i < wing.Count; i++)
                {

                    if (new Vec2(Input.mouseX - wing[i].x, Input.mouseY - wing[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

            }

        }


        if (currentScene == 4)
        {

            if (toExplode)
            {
                explosion.SetCycle(0, 5);
                explosion.Animate(0.1f);

                if (explosion.currentFrame == 4)
                {
                    mediumAsteroid.Remove();
                    LoadScene(1, 4);
                }
            }
            else
            {
                explosion.SetFrame(5);
            }




            if (satellite != null && laserPaths.Count == 0)
            {
                satellite.rotation = Mathf.Atan2(Input.mouseY - satellite.y, Input.mouseX - satellite.x) * (180 / Mathf.PI);
            }

            if (Input.GetMouseButtonDown(0))
            {
                for (int i = 0; i < 2; i++)
                {

                    if (Input.mouseX >= panels[i].x - panels[i].width / 2 && Input.mouseX <= panels[i].x + panels[i].width / 2 && Input.mouseY >= panels[i].y - panels[i].height / 2 && Input.mouseY <= panels[i].y + panels[i].height / 2)
                    {
                        isDragging = true;
                        whichPanel = i;
                    }
                }
            }




            if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;

                for (int i = 0; i < rocks.Count; i++)
                {

                    if (new Vec2(Input.mouseX - rocks[i].x, Input.mouseY - rocks[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

                for (int i = 0; i < wing.Count; i++)
                {

                    if (new Vec2(Input.mouseX - wing[i].x, Input.mouseY - wing[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

                for (int i = 0; i < rocket.Count; i++)
                {

                    if (new Vec2(Input.mouseX - rocket[i].x, Input.mouseY - rocket[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

            }
        }


        if (currentScene == 5)
        {

            if (toExplode)
            {
                explosion.SetCycle(0, 5);
                explosion.Animate(0.1f);

                if (explosion.currentFrame == 4)
                {
                    mediumAsteroid.Remove();
                    LoadScene(1, 5);
                }
            }
            else
            {
                explosion.SetFrame(5);
            }




            if (satellite != null && laserPaths.Count == 0)
            {
                satellite.rotation = Mathf.Atan2(Input.mouseY - satellite.y, Input.mouseX - satellite.x) * (180 / Mathf.PI);
            }

            if (Input.GetMouseButtonDown(0))
            {
                for (int i = 0; i < 2; i++)
                {

                    if (Input.mouseX >= panels[i].x - panels[i].width / 2 && Input.mouseX <= panels[i].x + panels[i].width / 2 && Input.mouseY >= panels[i].y - panels[i].height / 2 && Input.mouseY <= panels[i].y + panels[i].height / 2)
                    {
                        isDragging = true;
                        whichPanel = i;
                    }
                }
            }




            if (Input.GetMouseButtonUp(0))
            {
                isDragging = false;

                for (int i = 0; i <rocks.Count; i++)
                {

                    if (new Vec2(Input.mouseX - rocks[i].x, Input.mouseY - rocks[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }
                for (int i = 0; i < wing.Count; i++)
                {

                    if (new Vec2(Input.mouseX - wing[i].x, Input.mouseY - wing[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }

                for (int i = 0; i < rocket.Count; i++)
                {

                    if (new Vec2(Input.mouseX - rocket[i].x, Input.mouseY - rocket[i].y).Length() <= 35)
                    {

                        pannels[whichPanel].start = new Vec2(0, 0);
                        pannels[whichPanel].end = new Vec2(0, 0);

                        if (whichPanel == 0)
                        {
                            panels[whichPanel].SetXY(100, 700);
                        }
                        if (whichPanel == 1)
                        {
                            panels[whichPanel].SetXY(800, 700);
                        }
                    }
                }


            }
        }







        if (Input.GetKeyDown(Key.W))
        {
			if (laserPaths.Count > 0)
			{
				DestroyLaserPath();
			}

			Vec2 mousePosition = new Vec2(Input.mouseX, Input.mouseY);
            AddLaserPath(start, (mousePosition - start).Normalized());
        }


        textToShow = laserPaths.Count.ToString();

		//_text.Clear(Color.Transparent);
		//_text.Text(textToShow, 0, 0);
	}

    private void ClearLevel()
    {
        foreach (Sprite sprite in rocks)
        {
            sprite.Destroy();
        }
        rocks.Clear();

        foreach (Sprite sprite in wing)
        {
            sprite.Destroy();
        }
        wing.Clear();

        foreach (Sprite sprite in rocket)
        {
            sprite.Destroy();
        }
        rocket.Clear();

        foreach (Sprite sprite1 in panels)
        {
            sprite1.Destroy();
        }
        panels.Clear();

        foreach (LineSegment lineSegment in pannels)
        {
            lineSegment.Remove();
        }
        pannels.Clear();

        satellite.Remove();
        //explosion.Destroy();

        toExplode = false;
    }


    public void DestroyLaserPath() {

		foreach (LaserPath laser in laserPaths)
		{
			laser.Destroy();
		}
		laserPaths.Clear();
	}
	


}

